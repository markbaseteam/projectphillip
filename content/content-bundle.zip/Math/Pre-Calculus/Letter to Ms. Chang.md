---
tags:
- Math
Created: 2022-08-17 19:10  
---
# Letter to Ms. Chang 

Hello Ms. Chang, 

My name is Phillip Han, one of your students in block 7 pre-calc. When I meet new people, I don’t talk much about myself, but instead, I try to get people to talk about themselves. But when I do get to talk about myself, I love to talk about my hobbies, one of them being music. 

I play viola and piano and have been for multiple years. I enjoy listening to classical music, progressvie rock, jazz, and stuff from the 70s. I find finding people who share my musical taste very difficult, but I always ask to see if they do. If someone tells me that they play a musical instrument, my respect for that person increases immediately by 60%. I hope you do too, and if you don’t, I hope you start learning one in the near future. It’s okay if you don’t though; I will respect you regardless. One of my dreams is to sit down with someone and listen to the entirety of Liszt’s sonata in B minor or Rachmanioff’s 1st or 3rd concerto. I hope to do that one day. 

I also have a brother in 9th grade called Daniel. Whenever I see him, I hope that I wasn’t that annoying when I was two years younger. You might have him in two years. 

If there is one thing you should be aware of, it is that I will rarely, if at all, leave something I don’t completely understand. My intentions are never to disrupt the class, but I sometimes ask too many questions about a concept I don’t understand and slow down the entire class’s progress. If I do that, please remind me to shut up and tell me to meet you at a different time to talk. I will not be offended and save my questions for later. 