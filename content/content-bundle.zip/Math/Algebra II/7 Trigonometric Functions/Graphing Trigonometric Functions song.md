---
tags:
- Music
- Algebra_2
- Math
---
# Graphing Trigonometric Functions song 
Created: 2022-06-06 09:21  

Song based on [[7.4 Graphing Trigonometric Functions]]. Will cover Beatles’ [Yesterday](https://www.youtube.com/watch?v=NrgmdOz227I) using [this](https://youtu.be/0bmgruf_SpY) backing track. 

[[Yesterday Lyrics]]

## Things I need to add: 
- ![[7.4 Graphing Trigonometric Functions#Parts of a trignometric function]]
	- Include min/max after amplitude 
- ![[7.4 Graphing Trigonometric Functions#^11e8ef]]
- ![[7.4 Graphing Trigonometric Functions#Graph y a sin bx and y a cos bx]]
The period
squeezes or stretches the graph sideways 
the amplitude makes the graph tall or short 
midline moves the graph up and down 

first of all 
you have the period of the trig graph 
it’s the repeating part of the graph 
the period is the length of that 

the, fre-quency is related 
to the period 
its the number of 
cycles in an interval 

the amplitude 
is from the midline to the max or min 
you could say it’s the height of the graph 
note it’s always, positive 

next, we, have the midline which is 
the middle line 
between the highest and lowest 
points of the graph 

Next we can, 
Calculate the average rate of change 
The min, max, zeros can be used to find 
the slope between, the 3 endpoints 

[repeats here]

when, you, compare two different graphs 
check its key features 
com-pare, the period 
amplitude and frequency

finally 
this is the end of my trig graph song 
i hope ms brower likes my trig graph song 
oh i believe in her mercy 