---
tags:
- Science
- Definition
- Ecology
- Biology
---
# Biodiversity 
Created: 2022-06-08 08:19  

- The **diversity of living things** in an environment  ^05e849
- Rainforests have great biodiversity 
	- Covers around 7% of Earth's land, yet accounts for over 50% of all animal & plant species 