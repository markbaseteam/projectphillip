---
tags:
- Shakespeare
- English
---
# Act 5 Summary 
Created: 2022-05-22 15:59  

## [[Act 5 Scene 1|Scene 1]]: Romeo buys poison 
- [[Romeo]] finds out that [[Juliet]] is dead from [[Balthasar]]
- Romeo buys poison from a poor apothecary and decides to use kill himself with it in front of Juliet’s grave 

## [[Act 5 Scene 2|Scene 2]]: Letter never got sent to Romeo 
- [[Friar Lawrence]] finds out that his message to Romeo never got sent 
- He plans to quickly go to the tomb and wait for Romeo 

## [[Act 5 Scene 3|Scene 3]]: The death of Romeo and Juliet end the fued between the two familes 
- [[Paris]] scatters flowers over Juliet’s tomb 
- Romeo enters the graveyard and Paris hides 
- Romeo opens Juliet’s tomb 
- Paris catches him in the act 
- Romeo and Paris fight, and Romeo kills Paris 
	- Paris’s page runs away to call the officials 
- Romeo drinks the poison and dies 
- Friar Lawrence comes, but Juliet tells him to go away 
- Juliet promtly kills herself with Romeo’s knife just as the guards come 
- Everyone comes, including [[Lord Capulet]],[[ Lady Capulet]], [[Lord Montague]], and the [[Prince]]. 
- Friar Lawrence explains everything that happened 
- Lord Capulet and Lord Montague end the fued 