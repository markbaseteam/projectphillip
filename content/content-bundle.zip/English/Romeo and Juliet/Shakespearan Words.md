# Shakespearean Terminology 
Tags: #Shakespeare #English #Definition

Not all of these words were made by him, but just really old words that I can't remember the definitions of. 

**loin** 
genitalia 

**star-crossed**
destined match, yet unfavored by the stars 

**Lammastide** 
August 1

**cock-a-hoop** 
triumphantly pleased or boastful

**Aside** 
a remark or passage in a play that is intended to be heard by the audience but unheard by the other characters in the play 

**Character foil** 
a character whose purpose is to accentuate or draw attention to the qualities of another character

**Chorus** 
a group of performers who comment on the main action, typically speaking and moving together

**Hamartia** 
a fatal flaw leading to the downfall of a tragic hero or heroine (pronounced “ha-mar-tee-uh”) ^8e5992

**Soliloquy** 
an act of speaking one's thoughts aloud when by oneself or regardless of any hearers, especially by a character in a play.
