# Romeo and Juliet 
## ACT 4 SCENE 4 
### Hall in Capulet's house.

> _Enter LADY CAPULET and Nurse_

**LADY CAPULET**

> Hold, take these keys, and fetch more spices, nurse.  

**Nurse**

> They call for dates and quinces in the pastry.  
> 
> _Enter CAPULET_

**CAPULET**

> Come, stir, stir, stir! the second cock hath crow'd,  
> The curfew-bell hath rung, 'tis three o'clock:  
> Look to the baked meats, good Angelica:  
> Spare not for the cost.  

**Nurse**

> Go, you cot-quean, go,  
> Get you to bed; faith, You'll be sick to-morrow  
> For this night's watching.  

**CAPULET**

> No, not a whit: what! I have watch'd ere now  
> All night for lesser cause, and ne'er been sick.  

**LADY CAPULET**

> Ay, you have been a mouse-hunt in your time;  
> But I will watch you from such watching now.  
> 
> _Exeunt LADY CAPULET and Nurse_

**CAPULET**

> A jealous hood, a jealous hood!  
> 
> _Enter three or four Servingmen, with spits, logs, and baskets_
> 
> Now, fellow,  
> What's there?  

**First Servant**

> Things for the cook, sir; but I know not what.  

**CAPULET**

> Make haste, make haste.  
> 
> _Exit First Servant_
> 
> Sirrah, fetch drier logs:  
> Call Peter, he will show thee where they are.  

**Second Servant**

> I have a head, sir, that will find out logs,  
> And never trouble Peter for the matter.  
> 
> _Exit_

**CAPULET**

> Mass, and well said; a merry whoreson, ha!  
> Thou shalt be logger-head. Good faith, 'tis day:  
> The county will be here with music straight,  
> For so he said he would: I hear him near.  
> 
> _Music within_
> 
> Nurse! Wife! What, ho! What, nurse, I say!  
> 
> _Re-enter Nurse_
> 
> Go waken Juliet, go and trim her up;  
> I'll go and chat with Paris: hie, make haste,  
> Make haste; the bridegroom he is come already:  
> Make haste, I say.  
> 
> _Exeunt_