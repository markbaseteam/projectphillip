---
tags:
- china
- Photo
---
# Photos used for Mao vs 1984 project  
Created: 2022-05-30 07:06  

![[Pasted image 20220530070700.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fnamu.wiki%2Fw%2F1984(%25EC%2586%258C%25EC%2584%25A4)&psig=AOvVaw15nkqM5dFt-ikkYo17_JVi&ust=1653948263722000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCPCs08jbhfgCFQAAAAAdAAAAABAD)

gets screenshots from here: 
https://www.youtube.com/watch?v=PeGGOkBK1dY

![[Pasted image 20220601104354.png]][source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fmedium.com%2Fdharma-dispatch%2Fthe-writing-training-of-george-orwell-or-how-eric-arthur-blair-became-george-orwell-d2653e74b4f0&psig=AOvVaw0zo6zHFL253ZWF3pOSeYM6&ust=1654134168204000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCMDt0ZCQi_gCFQAAAAAdAAAAABAD)

[orwell signature ](https://commons.wikimedia.org/wiki/File:Orwell-Signature.svg)
[![File:Orwell-Signature.svg](https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Orwell-Signature.svg/512px-Orwell-Signature.svg.png?20111023215031)


![[Pasted image 20220601111826.png]][source](https://commons.wikimedia.org/wiki/File:1984JLH2.jpg)

![[Pasted image 20220601120743.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.bbc.com%2Fculture%2Farticle%2F20180507-why-orwells-1984-could-be-about-now&psig=AOvVaw13X8Wng99L6MBDq8EDoNtg&ust=1654139154431000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCMiFztqii_gCFQAAAAAdAAAAABAJ)

![[Pasted image 20220601132311.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fbookanalysis.com%2F1984%2Fthought-police%2F&psig=AOvVaw31MzC0pv9R-yvxjxleGT2E&ust=1654143644476000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCJCIv7ezi_gCFQAAAAAdAAAAABA8)

![[Pasted image 20220601133235.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.ft.com%2Fcontent%2F060cd74e-a327-49cc-8715-12b1d914de85&psig=AOvVaw2BTBAI-HF-rrWKrmbTvxZ5&ust=1654144661612000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCKCz15m3i_gCFQAAAAAdAAAAABAD)


![[Pasted image 20220601133701.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Ftheweek.com%2Farticles%2F694272%2Ffacebooks-thought-police&psig=AOvVaw0AxEJj-zbOe7H3rF7V9aVi&ust=1654144407610000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCKiy_KK2i_gCFQAAAAAdAAAAABA-)

https://www.sigross.com/blog/1984-stories/19/5/2019

![[Pasted image 20220601151617.png]]

![[Screen Shot 2022-06-01 at 3.59.35 PM.png]]
illustration by DAVIDE BONAZZI from [BBC world histories magazine issue 18 ](https://www.historyextra.com/magazine-issue/issue-18-october-november-2019/)

![[Screen Shot 2022-06-01 at 4.14.30 PM.png]]
Illustration by ben jones (from the same place)

![[Pasted image 20220601163641.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fphilosophyofshaving.wordpress.com%2F2017%2F02%2F11%2F225%2F&psig=AOvVaw1-3HzmL1EgPudwW4VkhmDG&ust=1654155366519000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCPCi9Irfi_gCFQAAAAAdAAAAABAD) 

![[Pasted image 20220601172437.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.thecuriousreader.in%2Ftata-lit-live%2Fgeorge-orwell-1984%2F&psig=AOvVaw1M_opl0x3vGRur2BqhGsU7&ust=1654158192226000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCMiAvM7pi_gCFQAAAAAdAAAAABAw)

![[Pasted image 20220601201132.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.itpro.com%2Fsecurity%2F362302%2Fonly-use-black-bars-to-redact-text-warns-researcher&psig=AOvVaw0_cvY2pw8BBh1nCs0vr6B5&ust=1654168279440000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCNizjpiPjPgCFQAAAAAdAAAAABAD)

![[Screen Shot 2022-06-02 at 6.50.06 AM.png]]

![[Pasted image 20220602090108.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Flibertymaniacs.com%2Fproducts%2Fingsoc-1984-over-there-propaganda-poster&psig=AOvVaw3WXiiXgsJXa569mZSMsgUl&ust=1654214329265000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCIjeyeC6jfgCFQAAAAAdAAAAABBJ)

![[Pasted image 20220602102326.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.amazon.com%2Fpropaganda-advertising-Everything-Subscribe-much-needed%2Fdp%2FB07DPM5W1J&psig=AOvVaw047dY3VtrmHm4JMVoxpfGE&ust=1654219199039000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCOjPjPTMjfgCFQAAAAAdAAAAABAP)

![[Pasted image 20220602102344.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.travelpostersonline.com%2Fvintage-russian-war-propaganda-poster---1920-10383-p.asp&psig=AOvVaw047dY3VtrmHm4JMVoxpfGE&ust=1654219199039000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCOjPjPTMjfgCFQAAAAAdAAAAABAV)

![[Pasted image 20220602103201.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fkatehon.com%2Fen%2Farticle%2Freinventing-emmanuel-goldstein&psig=AOvVaw3oWg0F_Y9v6qOGnwYNQTBw&ust=1654219886860000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCJDIubvPjfgCFQAAAAAdAAAAABAD)

![[Pasted image 20220602122727.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.artmajeur.com%2Fen%2Fnervf%2Fartworks%2F11204872%2Fdemon-of-revolution&psig=AOvVaw0WCmOOLhaQMRkgaJ08Ceuc&ust=1654226837745000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCOjEuavpjfgCFQAAAAAdAAAAABAD) 

![[Pasted image 20220602122911.png]]
[source](https://www.amazon.com/Buyenlarge-Lenin-Lived-Poster-30-Inch/dp/B00T0BN5G6) 

![[Pasted image 20220602125451.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fthenounproject.com%2Ficon%2Fyou-4145382%2F&psig=AOvVaw2U5r0ZXSBbT196Jkyw7A9D&ust=1654228464615000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCKDDnbPvjfgCFQAAAAAdAAAAABAD)

![[Pasted image 20220602125659.png]]
[source](https://www.google.com/url?sa=i&url=https%3A%2F%2Fthenounproject.com%2Ficon%2Fvillain-3346149%2F&psig=AOvVaw0g3BObuwuNdbIw5Y0AGiPr&ust=1654228586724000&source=images&cd=vfe&ved=0CAwQjRxqFwoTCNCB1uvvjfgCFQAAAAAdAAAAABAD)

![[Pasted image 20220602155106.png]]

[![File:Panchen Lama during the struggle (thamzing) session 1964.jpg](https://upload.wikimedia.org/wikipedia/commons/0/03/Panchen_Lama_during_the_struggle_%28thamzing%29_session_1964.jpg?20150205165629)](https://upload.wikimedia.org/wikipedia/commons/0/03/Panchen_Lama_during_the_struggle_%28thamzing%29_session_1964.jpg)
[source](https://commons.wikimedia.org/wiki/File:Panchen_Lama_during_the_struggle_(thamzing)_session_1964.jpg) 