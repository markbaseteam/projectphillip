---
tags:
- English
- Shakespeare
---
# Juliet's fate 
Created: 2022-05-20 06:19  

*Was this Juliet's only future, or did Juliet make her own?* 

(Make a mind map of this by Command + M) 

## [[Juliet]] tells [[Romeo]] that she will marry Romeo 

### Juliet sends the [[Nurse]] to Romeo 

#### [[Friar Lawrence]] marries together Juliet and Romeo 

##### Juliet finds out that Romeo is banished from Verona 

###### Juliet drinks the vial Friar Lawrence gave her 

### Juliet waits a little more to actually marry 

#### Romeo is disinterested in slow love and goes off to find another woman 

#### Romeo and Juliet stay as very close friends for a while 

##### They get caught dating 

###### Both are executed or only one is executed for even more pain to the other 

##### They spend many days happy, and end the fued between the two familes 

#### Juliet and Romeo don't enjoy the un-thrilling relationship and leaves each other 

## Juliet shoos Romeo away 

### Juliet lives on with her rich life and parties 

### Juliet's uncontrollable love for Romeo leads her back to Romeo 
