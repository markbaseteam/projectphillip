---
tags:
- History
- SoutheastAsia
- Asia
Created: 2022-08-22 18:30  
---
# Melaka
A state in Malaysia today.

![[Pasted image 20220828202132.png]]
<center> <i>Melaka took advantage of the Strait of Malacca (Melaka) and controlled trade that went through there.</i></center>

## Origins 
- History starts from the 1400s 
- Parameswara, a Sumatran prince, flees his country from the attacking Majapahit Empire, goes to Temasek, kills ruler, gets kicked out from Thai army, then stumbles upon Melaka  
- Parameswara converts to Islam and becomes the [[Sultanate|Sultan]] of Melaka 

## Trading 
- “The city was also growing into a prominent trading ground for traders from across Asia, notably India, Arabia and China. As a result, many Chinese migrants settled here during this time, establishing the Peranakan culture for the future.” (Source: [Jay’s website](https://sites.google.com/kis.or.kr/ap-world/units/information-and-slides/south-south-east-asia?authuser=0#h.p_b0aVsbaJCG5A))