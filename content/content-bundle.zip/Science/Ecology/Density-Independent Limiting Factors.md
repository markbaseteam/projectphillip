---
tags:
- Science
- Definition
- Ecology
---
# Density-Independent Limiting Factors 
Created: 2022-06-08 08:12  

- Limiting factors that **are not affected by the population density** 
- **Unusual weather & Natrual disasters** 
	- Weather or natural disasters can't be affected by how dense a population is 
	- Both can disrupt the ecosystem 
		- ex. a tsunami can destroy coral reefs, which will be felt by most members in that ecosystem 
- **Human activities**
	- Humans being the greedy and careless assholes they are destroy the ecosystem 
		- Clearing forests, polluting the air, water, land, etc. 