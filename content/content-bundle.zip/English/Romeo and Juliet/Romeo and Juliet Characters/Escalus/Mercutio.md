# Mercutio 
Created: 2022-04-24 19:37
Tags: #English #Shakespeare #Character 

Mercutio is a funny guy who is friends with Romeo. 

quick description 
- age: 16 or 17 
- sex: male 
- **Flat character.** A flat character has one or two personality traits that don't change. The flat character can play a major or a minor role.

## Family 
- From the House of #Escalus 
- Uncle: [[Prince Escalus]] 
- Brother: Valentine 

## Friends & Enemies 
Understand the relationships Mercutio has with influential characters in the story is important to analyzing his character and better understand how and why certain events happened. The people are ranked in how much they love or hate them, but it's all general. 

### Friends 
1. [[Romeo]] 
2. [[Benvolio]]
3. 

### Enemies 
1. [[Tybalt]]

## Characteristics
- Loves to talk 
	- Through his almost excessive talking, Mercutio makes all kinds of jokes to anyone he meets. Romeo describes his passion for talking to the Nurse in Act 2 Scene 4: ![[Act 2 Scene 4#^84088c]](Shakespeare 2.4.126)


## Ideology 
- Views love as one's sexual appetite 

## Motivations 
- **Distract Romeo from Rosaline** 
	- The famous Queen Mab speech is a prime example of Mercutio's attempts to distract Romeo from Rosaline and stop him from being depressed all the time. ![[Act 1 Scene 4#^54c9b3]]



## Changes in Character 
1. first 
2. second 
3. third 

## Hamartia 
- always joking 
- insults everyone around him constantly 
- quick temper 