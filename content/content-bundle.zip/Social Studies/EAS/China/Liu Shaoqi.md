---
tags:
- China
- Person
- EAS
---
# Liu Shaoqi 
Created: 2022-05-14 07:37  

>"Goldstein of China"

## Header 
- things 

---
## References 
- 