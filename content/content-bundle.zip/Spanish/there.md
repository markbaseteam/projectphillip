---
tags:
- Spanish
- Word
Created: 2022-08-20 17:33  
---
# there 
![[Pasted image 20220820174236.png]]

ADVERB
used to indicate place 

1. **ahí** (close to the listener)
You can leave your coat there. 
>Puedes dejar tu abrigo ahí.

2. **allí** (further away from the listener)
I left the books there because I didn't know where to put them.
>Dejé los libros allí porque no sabía dónde ponerlos.

3. **allá** (even further away from the listener)
I have a friend who lives in London. I'm going to visit him there in October. 
>Tengo un amigo que vive en Londres. Voy a visitarlo allá en octubre.

## Pronounciation 
[aya](https://www.spanishdict.com/pronunciation/all%C3%A1?langFrom=es) 

## Examples 
After camping next to the beach, we slept there. 
>Despues acampar al lado del costa, nosotros dormimos allá. 

