---
tags:
- China
- EAS
- History
- extract
---
# The Theory and Practice of Chinese Revisionism and Social Imperalism 
Created: 2022-06-02 18:15  

>The Chinese revisionists didn’t rest content with this slander on Marx’s analysis as being “abstract”, but they went further–they went on to say that Marx didn’t envisage commodity production and class struggle in the first phase of communism. But why have the Chinese revisionists done this? Because, they see it necessary to totally distort Marxism-Leninism, in order to have the proletariat and labouring masses of China accept Mao Tse-tung’s theory as the only “genuine revolutionary” theory, and thus, prepare better conditions to go all out for developing capitalist relations further, expanding its bureaucracy by bringing in more technocrats, specialists, experts, trained by the Yugoslav revisionists, and by Japanese and U.S. imperialism. Their aims of following Mao’s behest, of making China a superpower “by the year 2000”, they thus, hope to realize.

---
## References 
- https://www.marxists.org/history/erol/ncm-5/core-china.htm