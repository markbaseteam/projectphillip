---
tags:
- Science
- Chemistry
- Definition
Created: 2022-08-18 21:11  
---
# Atom 
The smallest unit of ordinary matter that forms a chemical element. ([Wikipedia](https://en.wikipedia.org/wiki/Atom))

![[Pasted image 20220820215220.png]]


![[Pasted image 20220820215230.png]]

![[Pasted image 20220820215241.png]]