# Act 1 Scene 5 Notes 
[[Act 1 Scene 5#^30cdf0|1.5.91]] 
- shows their innocence 