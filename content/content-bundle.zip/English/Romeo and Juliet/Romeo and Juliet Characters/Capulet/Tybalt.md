# Tybalt 
Created: 2022-04-22 13:11
Tags: #English #Shakespeare #Character 

quick description 
- age: 
- sex: male 
- Stock or stereotype character 
- Antagonist 

## Family 
- From the House of #Capulet 
- Father: [[]] 
- Mother: [[]] 
- Uncle: [[Capulet]]

## Friends & Enemies 
Understand the relationships Tybalt has with influential characters in the story is important to analyzing his character and better understand how and why certain events happened. The people are ranked in how much they love or hate them, but it's all general. 

### Friends 
1. 

### Enemies 
1. [[Romeo]]

## Characteristics
- 

## Ideology 
- 

## Motivations 
- 



## Changes in Character 
1. first 
2. second 
3. third 

## Hamartia 
- Too protective with his honor 
- Holds all of his grudges 