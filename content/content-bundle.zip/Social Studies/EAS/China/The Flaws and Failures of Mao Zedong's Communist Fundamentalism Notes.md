---
tags:
- China
- EAS
- History
---
# The Flaws and Failures of Mao Zedong's Communist Fundamentalism Notes 
Created: 2022-05-17 06:31  

## 3 main things he failed  
1. zero democracy 
2. increased gap between the urban & rural areas 
3. china was vulnerable to foreign enemies and famines 

## What contributed to Maoism 
- Ancient Chinese culture and history also fostered the establishment of this god-like ruler 
- in the ming dynasty, conservative elites used the military to keep the people pure from "foregin pollution" for support 
	- it doens't solve any problems but it works 

"Mao proved time and again that he understood the innermost hates and hopes of his nation."

---
## References 
- [[The Flaws and Failures of Mao Zedong's Communist Fundamentalism.pdf]]