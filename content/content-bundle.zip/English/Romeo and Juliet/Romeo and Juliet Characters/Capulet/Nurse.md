# Nurse 
Created: 2022-04-25 08:19
Tags: #English #Shakespeare #Character 

quick description 
- age: pretty old 
- sex: female 
- **Flat character.** A flat character has one or two personality traits that don't change. The flat character can play a major or a minor role. 
- Foil 

## Family 
- From the House of #Capulet 

## Friends & Enemies 
Understand the relationships Nurse has with influential characters in the story is important to analyzing her character and better understand how and why certain events happened. The people are ranked in how much they love or hate them, but it's all general. 

### Friends 
1. [[Juliet]] 
2. [[Lord Capulet]]
3. [[Lady Capulet]]
4. [[Tybalt]]
5. [[romeo]]

### Enemies 
1. [[Mercutio]]

## Characteristics
- **Witty** 
	- There are many instances where the Nurse provides the play comic relief. One instance is in Act 2 Scene 5 when the nurse returns to Juliet with news of Juliet's marriage with Romeo. She delays telling Juliet for some time, because she thinks it's funny. I'm sure Juliet didn't fully appreciate her joke. ![[Act 2 Scene 5#^448974]] (Shakespeare 2.5.25-26) 

## Ideology 
- Love is mostly physical and temporary 
	- The Nurse can't understand Juliet's intense love for Romeo 

## Motivations 
- **Juliet's marriage**
	- At first, she supports Juliet's intentions to marry Romeo and helps her in doing so. In Act 2 Scene 4, the Nurse goes to Romeo and tells him of the arrangements herself, and it's noticeable that the Nurse really wants Juliet to marry with Romeo, not Paris. She knows that Juliet loves Romeo way more, and wants the best for Juliet. ![[Act 2 Scene 4#^448fd4]]
	- The nurse also wants to protect Juliet, saying that the "gentlewoman" (Juliet) is young, and Romeo "should deal double with her," meaning if he tricks her, it would be very bad. ![[Act 2 Scene 4#^741cdc]](Shakespeare 2.4.138-146)



## Changes in Character 
1. Supports Romeo and Juliet's marriage 
2. Goes against it 
3. third 

## Hamartia 
- Too loyal 