---
tags:
- Science
- Chemistry
- Definition
Created: 2022-08-18 21:07  
---
# Mass 

Measure of matter.  ^f7973d

![[Pasted image 20220818210846.png]]