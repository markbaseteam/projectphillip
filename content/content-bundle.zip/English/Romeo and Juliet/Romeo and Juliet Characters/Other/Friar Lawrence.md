# Friar Lawrence
Created: 2022-04-22 12:54
Tags: #English #Shakespeare #Character 

Friar Lawrence is a somewhat witchy character that is mysterious. He marries Romeo and Juliet. 

- age: pretty old 
- sex: male 
- Foil 
- **Flat character.** A flat character has one or two personality traits that don't change. 

## Friends & Enemies 
Understand the relationships Friar Lawrence has with influential characters in the story is important to analyzing his character and better understand how and why certain events happened. The people are ranked in how much they love or hate them, but it's all general. 

### Friends 
1. [[Romeo]]
2. [[Juliet]]

### Enemies 
1. 

## Characteristics 
- More Pagan (pre-Christian) than Christian 
	- Mother Nature 
- Optimist 

## Ideology 
- Pure evil or good does not exist 

## Motivations 
- He hopes for the Montague and Capulet family to be peaceful 
- He tells Romeo that too much love can be harmful 

> These violent delights have violent ends  
> And in their triumph die, like fire and powder,  
> Which as they kiss consume: the sweetest honey  
> Is loathsome in his own deliciousness  
> And in the taste confounds the appetite:  
> Therefore love moderately; long love doth so;  
> Too swift arrives as tardy as too slow.  

## Changes in Character 
1. first 
2. second 
3. third 

## Hamartia 
- Cares too much about the greater good than the individual 
- Optimist 
	- two kids marrying sounds like a terrible idea but it *might* save verona so lets go 