# My Pizza Choices 
Created: 2022-04-21 06:01
Tags: #Math #Algebra_2 #Probability 

Look at the mind map of this to get a sense of the fundamental counting principal. 

## Medium 
### Deep dish 
#### Sausage 
#### Pepperoni 
#### Cheese 

### Thin dish 
#### Sausage 
#### Pepperoni 
#### Cheese 

## Large 
### Deep dish 

#### Sausage 
#### Pepperoni 
#### Cheese 

### Thin dish 
#### Sausage 
#### Pepperoni 
#### Cheese 

12 total different types of pizza (2 size x 2 crust style x 3 toppings)