---
tags:
- Science
- Chemistry
- Definition
Created: 2022-08-18 21:10  
---
# Matter 

Anything that has mass and volume. Made up of [[atom|atoms]] and [[Molecule|molecules]]. 

![[Pasted image 20220818211056.png]]