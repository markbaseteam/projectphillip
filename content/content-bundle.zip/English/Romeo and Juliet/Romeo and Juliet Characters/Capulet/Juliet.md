# Juliet 
Created: 2022-04-26 05:29
Tags: #English #Shakespeare #Character 

quick description 
- age: 13 
- sex: female 
- Round character 

## Family 
- From the House of #Capulet 
- Father: [[Lord Capulet]] 
- Mother: [[Lady Capulet]] 
- Cousin: [[Tybalt]]
- Cousin: [[Rosaline]]

## Friends & Enemies 
Understand the relationships Juliet has with influential characters in the story is important to analyzing her character and better understand how and why certain events happened. The people are ranked in how much they love or hate them, but it's all general. 

### Friends 
1. [[Romeo]]
2. [[Nurse]]
3. [[Tybalt]]

### Enemies 
1. [[Lord Capulet]]
2. [[Lord Montague]]
3. [[Nurse]]
4. [[Romeo]]

## Characteristics
- **Obedience** 
	- When Lady Capulet asks Juliet whether or not she would marry Paris, she doesn't think too much of marriage and obeys her mother. ![[Act 1 Scene 3#^29711c]]
- **Initiative**
	- In the balcony scene in Act 2 Scene 2, Juliet is the first one to tell Romeo that they will be married, taking the initiative herself to plan out her own life ![[Act 2 Scene 2#^55f095]]
## Ideology 
- 

## Motivations 
- Wants to please her mother by marrying Paris (Shakespeare 1.3.99-101)
	- ![[Act 1 Scene 3#^29711c]]
- Marry Romeo (Shakespeare 1.5.3-4)
![[Act 1 Scene 5#^ddb4c0]]

## Changes in Character 
1. Falling in love with Romeo makes her more mature and control her life more 
2. But she thinks she's more mature than she actually is 

## Hamartia 
- Too impulsive with her decisions 
- Naive 

<progress value="90" max="100"></progress>