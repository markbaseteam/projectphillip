#### Carrying capacity 
- The **maximum population size** an environment can stably support 
	- Natrual cycles and species diversity can determine this upper limit 
- The carrying capacity also constantly changes due to the consantly changing environment 