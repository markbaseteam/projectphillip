---
tags:
- extract
- Japan
- Eas
- history
---
# Article 9 of the Japanese Constitution 
Created: 2022-05-31 09:46  

Aspiring sincerely to an international peace based on justice and order, the Japanese people forever renounce war as a sovereign right of the nation and the threat or use of force as means of settling international disputes.  

In order to accomplish the aim of the preceding paragraph, land, sea, and air forces, as well as other war potential, will never be maintained. The right of belligerency of the state will not be recognized.