# Romeo and Juliet 
## ACT 5 SCENE 2
### Friar Laurence's cell.

> _Enter FRIAR JOHN_

**FRIAR JOHN**

> Holy Franciscan friar! brother, ho!  
> 
> _Enter FRIAR LAURENCE_

**FRIAR LAURENCE**

> This same should be the voice of Friar John.  
> Welcome from Mantua: what says Romeo?  
> Or, if his mind be writ, give me his letter.  

**FRIAR JOHN**

> Going to find a bare-foot brother out  
> One of our order, to associate me,  
> Here in this city visiting the sick,  
> And finding him, the searchers of the town,  
> Suspecting that we both were in a house  
> Where the infectious pestilence did reign,  
> Seal'd up the doors, and would not let us forth;  
> So that my speed to Mantua there was stay'd.  

**FRIAR LAURENCE**

> Who bare my letter, then, to Romeo?  

**FRIAR JOHN**

> I could not send it,--here it is again,--  
> Nor get a messenger to bring it thee,  
> So fearful were they of infection.  

**FRIAR LAURENCE**

> Unhappy fortune! by my brotherhood,  
> The letter was not nice but full of charge  
> Of dear import, and the neglecting it  
> May do much danger. Friar John, go hence;  
> Get me an iron crow, and bring it straight  
> Unto my cell.  

**FRIAR JOHN**

> Brother, I'll go and bring it thee.  
> 
> _Exit_

**FRIAR LAURENCE**

> Now must I to the monument alone;  
> Within three hours will fair Juliet wake:  
> She will beshrew me much that Romeo  
> Hath had no notice of these accidents;  
> But I will write again to Mantua,  
> And keep her at my cell till Romeo come;  
> Poor living corse, closed in a dead man's tomb!  
> 
> _Exit_