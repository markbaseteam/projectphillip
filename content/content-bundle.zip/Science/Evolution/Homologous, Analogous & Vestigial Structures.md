# Homologous, Analogous & Vestigial Structures 
Tags: #Biology #Science 
How they are evidence of evolution 

how did life evolve

evidence of evolution 
- DNA 
- Fossils 
- Embryology 
- Anatomy 

**Note: evolution is gradual**

## Fossils 
physical traits in the fossils that match with other species can signal evolutionary links 

## Embryology 
- study of early stages of organism development 
similar embryo sturcutre can infer relatedness 

## Anatomy 
- comparing body parts os species to determine their relatedness 

### homologous sturcutre
stuctures that evolved frmo the same original structure but doen't necessarily have the same function:*same sturcutre, different function*

ex. human, cat, whale, bat arms ![[600px-Homology_vertebrates-en.svg.png]]

## Analogous structure 
sturctures that have a similar function, but do not come from the same original structure: *same function, different sturcutre*

ex. dragonflies, birds, bats 

**vestigial sturcutres**
sturcutres or behaviors inherited frmo ancestors that no longer hsve any function 

ex. ostrich wings, human tails, Palmar Grasp (reflex)

ear muscles 
Goosebumps 
fish gills in the human ear (little bump)