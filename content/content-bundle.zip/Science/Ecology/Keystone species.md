---
tags:
- Science
- Definition
- Ecology
- Biology
---
# Keystone species 
Created: 2022-06-08 08:21  

![[Pasted image 20220429062247.png]]
- A species that has an unusually large effect on its ecosystem 
	- Holds its ecosystem together like a keystone shown above 
- ex. beavers 
	- Constructs dams 
	- The dams change the ecosystem's environment drastically and many species start to rely on it 
- ex. daphnia 
	- Composes a large portion of sportfish’s diet 