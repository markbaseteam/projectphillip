# The United Nations 



Formed in 1945 to maintain international peace and security.

Five Permanent Security Council Members (Can veto any action) - US, UK, France, China (held by ROC until 1971), USSR.

The Cold War often affected the UN’s ability to act in conflicts - 2 exceptions:

In 1950 the USSR was absent for the vote to intervene in the Korean War.

Signing of the Korean Armistice Agreement in 1953.

