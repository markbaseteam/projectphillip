---
tags:
- Asia
- History
Created: 2022-08-23 06:16  
---
# Mongol Empire 

![[Mongol_Empire_map.gif]]

## Positive characteristics 
### Culture 
- Religious tolerance 
	- allowed any religion to be practiced, as long as they prayed for them 

### Social
- Instead of killing experts, they forced them to different parts of their empire and spread their expertise 

#### Women 
- “Traditionally among the Mongols, women managed the affairs at home, while men went off to herd, hunt or fight.” (The Globalist) 
- One of Ogodei’s wives, Toregene, helped rule the empire 

>While the men fought, she pursued an entirely different line of activities supporting religion, education and construction projects on an imperial scale.



### Economics 
- Flourished trade 
	- Silk road + sea trade 

---
## References 
- https://www.theglobalist.com/the-women-who-ruled-the-mongol-empire/
- https://www.youtube.com/watch?v=wUVvTqvjUaM