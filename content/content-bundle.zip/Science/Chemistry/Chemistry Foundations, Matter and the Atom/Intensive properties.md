---
tags:
- Science
- Chemistry
- Definition
Created: 2022-08-18 21:35  
---
# Intensive properties 

A property that does *not* depend on the amount of matter present.  ^946708

Examples include: 
- Pressure 
- Density 
- Melting point 
- Conductivity 

![[Pasted image 20220818213957.png]]

Opposite of [[Extensive properties]]