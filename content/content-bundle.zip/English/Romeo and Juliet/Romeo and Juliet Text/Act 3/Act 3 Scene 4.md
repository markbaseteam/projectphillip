# Romeo and Juliet 
## ACT 3 SCENE 4 
### A room in Capulet's house.

> _Enter CAPULET, LADY CAPULET, and PARIS_

**CAPULET**

> Things have fall'n out, sir, so unluckily,  
> That we have had no time to move our daughter:  
> Look you, she loved her kinsman Tybalt dearly,  
> And so did I:--Well, we were born to die.  
> 'Tis very late, she'll not come down to-night:  
> I promise you, but for your company,  
> I would have been a-bed an hour ago.  

**PARIS**

> These times of woe afford no time to woo.  
> Madam, good night: commend me to your daughter.  

**LADY CAPULET**

> I will, and know her mind early to-morrow;  
> To-night she is mew'd up to her heaviness.  

**CAPULET**

> Sir Paris, I will make a desperate tender  
> Of my child's love: I think she will be ruled  
> In all respects by me; nay, more, I doubt it not.  
> Wife, go you to her ere you go to bed;  
> Acquaint her here of my son Paris' love;  
> And bid her, mark you me, on Wednesday next--  
> But, soft! what day is this?  

**PARIS**

> Monday, my lord,  

**CAPULET**

> Monday! ha, ha! Well, Wednesday is too soon,  
> O' Thursday let it be: o' Thursday, tell her,  
> She shall be married to this noble earl.  
> Will you be ready? do you like this haste?  
> We'll keep no great ado,--a friend or two;  
> For, hark you, Tybalt being slain so late,  
> It may be thought we held him carelessly,  
> Being our kinsman, if we revel much:  
> Therefore we'll have some half a dozen friends,  
> And there an end. But what say you to Thursday?  

**PARIS**

> My lord, I would that Thursday were to-morrow.  

**CAPULET**

> Well get you gone: o' Thursday be it, then.  
> Go you to Juliet ere you go to bed,  
> Prepare her, wife, against this wedding-day.  
> Farewell, my lord. Light to my chamber, ho!  
> Afore me! it is so very very late,  
> That we may call it early by and by.  
> Good night.  
> 
> _Exeunt_