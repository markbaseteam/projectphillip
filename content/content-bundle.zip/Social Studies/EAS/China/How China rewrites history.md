---
tags:
- China
- History
---
# How China rewrites history 
Created: 2022-05-27 12:41  

>“Both Imperial China and the PRC have maintained an official record depicting China as a victim of Western imperialism.” 

ex. blaming the Korean War entirely on the US and their imperialistic influence 

[[Deng Xiaoping and the "1981 Reolution"]]
- To maintain the Party’s control, China uses a central figure to guide the country 
	- Mao Zedong 
	- Deng Xiaoping 
	- Xi Jinping 

[[40 Years of Personal Repression]]
- China hides their repressive acts behind a larger enemy–the US 

>”However, when analyzed closely, the CCP’s detachment from reality, and stringent strategy of historical reconstruction, indicates a fearful state that is grasping for control to conceal the truth whenever reality does not align with its interests. The result is the CCP’s forceful effort to maintain dominance and strengthen Party rule within China, and its greater willingness to counter perceived threats and assert Chinese power beyond its borders.”

---
## References 
- https://project2049.net/2017/07/19/1984-with-chinese-characteristics-how-china-rewrites-history/