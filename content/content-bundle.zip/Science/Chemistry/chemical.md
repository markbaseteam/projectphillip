---
tags:
- Definition
- Science 
- Chemistry
Created: 2022-08-13 17:37  
---
# chemical 

:any substance that has a definite composition 

If we know for sure what it’s made of every single time, then it is a chemical. 

>[!example] ex. zinc, helium, oxygen 

“Some references add that chemical substance cannot be separated into its constituent elements by physical separation methods, i.e., without breaking chemical bonds.” ([Wikipedia](https://en.wikipedia.org/wiki/Chemical_substance))

