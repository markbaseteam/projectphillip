---
tags:
- Science
- Definition
- Ecology
---
# Population Crash 
Created: 2022-06-08 08:09  

- A sudden decrease in population size 
- Many factors can cause a population crash 
	- Seasons 
	- Natural disaster 
	- Disease 
	- [[14.2 Community Interactions#Predation|Predation]] 
	- Invasive species 