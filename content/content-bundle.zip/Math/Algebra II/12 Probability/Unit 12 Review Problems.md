---
tags:
- Math
- Algebra_2
- Probability
---
# Unit 12 Review Problems 
Created: 2022-05-17 16:00  

## conditional 
![[Unit 12 Review Problems 2022-05-17 18.06.58.excalidraw]]

## Probability distributions & binomial 
![[Probability distributions review problems]]

## combination and permutation 
![[Unit 12 Review Problems 2022-05-17 16.19.50.excalidraw]]

## probability 
![[Unit 12 Review Problems 2022-05-17 16.56.24.excalidraw]]

## Expected Value 
![[Unit 12 Review Problems 2022-05-17 21.01.29.excalidraw]]