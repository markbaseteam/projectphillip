---
tags:
- Science
- Chemistry
- Definition
Created: 2022-08-18 21:31  
---
# Extensive properties 
A property that depends on the amount of matter present.  ^dc0bb3

Examples include: 
- Volume 
- Mass
- Size 
- Weight 
- Length 

Opposite of [[intensive properties]]. 