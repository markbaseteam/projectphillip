# Romeo and Juliet 
## ACT 2 PROLOGUE 
### PROLOGUE 

> _Enter Chorus_

**Chorus**

> Now old desire doth in his death-bed lie,  
> And young affection gapes to be his heir;  
> That fair for which love groan'd for and would die,  
> With tender Juliet match'd, is now not fair.  
> Now Romeo is beloved and loves again,  
> Alike betwitched by the charm of looks,  
> But to his foe supposed he must complain,  
> And she steal love's sweet bait from fearful hooks:  
> Being held a foe, he may not have access  
> To breathe such vows as lovers use to swear;  
> And she as much in love, her means much less  
> To meet her new-beloved any where:  
> But passion lends them power, time means, to meet  
> Tempering extremities with extreme sweet.  
> 
> _Exit_
