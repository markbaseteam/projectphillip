# Romeo and Juliet Full Text 
Tags: #English #Extract #Shakespeare 
Here are the links to access every scene in Shakespeare's *Romeo and Juliet.* 

## Act 1 
[[Act 1 Prologue]]
[[Act 1 Scene 1]]
[[Act 1 Scene 2]]
[[Act 1 Scene 3]]
[[Act 1 Scene 4]]
[[Act 1 Scene 5]]

## Act 2
[[Act 2 Prologue]]
[[Act 2 Scene 1]]
[[Act 2 Scene 2]]
[[Act 2 Scene 3]]
[[Act 2 Scene 4]]
[[Act 2 Scene 5]]
[[Act 2 Scene 6]]

## Act 3 
[[Act 3 Scene 1]]
[[Act 3 Scene 2]]
[[Act 3 Scene 3]]
[[Act 3 Scene 4]]
[[Act 3 Scene 5]]

## Act 4 
[[Act 4 Scene 1]]
[[Act 4 Scene 2]]
[[Act 4 Scene 3]]
[[Act 4 Scene 4]]
[[Act 4 Scene 5]]

## Act 5
[[Act 5 Scene 1]]
[[Act 5 Scene 2]]
[[Act 5 Scene 3]]