---
tags:
- History
- Definition
Created: 2022-08-20 16:18  
---
# Sultanate 
A state/country ruled by a sultan, which are local kings. 

Examples: 
- [[Delhi Sultanate]]