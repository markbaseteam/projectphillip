---
tags:
- Japan
- EAS
- History
---
# Should Japan Remilitarize? 
Created: 2022-05-31 09:52  

- Shinzō Abe is getting ready to build a military for an offensive military 
- Government urges people to enlist through advertisements 
- Military is now a prestigious career 
- Ultra-nationalists want the glory days back 
	- Kick out the Chinese and Koreans 
	- “restore their history”

Japan cannot defend itself from China. China’s military is just too strong. 

---
## References 
- https://youtu.be/hcQTysyGwKQ 