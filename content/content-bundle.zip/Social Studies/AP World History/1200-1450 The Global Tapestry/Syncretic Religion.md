---
tags:
- History
- Religion
Created: 2022-08-20 16:08  
---
# Syncretic Religion 
A combination of multiple religions into one. A type of [[Examples of Cultural Diffusion|cultural diffusion]]. 

Examples: 
Sikhism (Northern India), Vodou (carribean), Sufism (Islam + Hinduism) 