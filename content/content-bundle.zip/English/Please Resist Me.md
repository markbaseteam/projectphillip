# Please Resist Me 
#### By Luka Lesson

Tags: #poetry #English #Poem

Please resist me

Colonise me, compromise me, conflict me
	*alliteration*
Please don't risk me

If you see me at the airport

Please come and frisk me


Please resist me

Colonise me, compromise me and conflict me

Please don't risk me

Please call me stupid

Because your resistance

Brings our [[Evolution]]

  

Please resist me

Call me a wog
	*wog: not white*
It’s brought us so close together I could call me a squad

Please resist me

Lock me in solitary confinement

I'll close my eyes and admire the quality of the silence

I'll write rhymes in my mind honestly and define them

Solidly redefine and memorise them

Until like a diamond

When I come out I’ll be better than when I arrived in


Please resist me,
	*irony*
Keep me under the thumb
	*idiom*
Keep me down-trodden keep me under the gun
	*idiom–means to keep under pressure*
Keep me working harder under thunder and sun
	*contrast, imagery*
Son - haven't you heard?
	*rhetorical question*
I'm becoming a gun
	*symbolism, metaphor*
  

Please resist me

Because resistance brings evolution

And you've resisted me so consistently

I thank you for your contribution

I'm a happy man

Your stupidity has made me strong

I've developed wings

A thick skin

and this here opposable thumb

It holds my pen which loads my explodable tongue

So without loading a gun

I'm killing high quotas of unemotional

punks

  

Sorry

You also taught me to speak French

I learnt it when you kept keeping me at arms-length

And then I learnt Italian just to expand my head

And Greek to learn from where my ancestors had fled

And then I learnt some Yanyuwa

Just to show the people of this land respect

You see

It's been your example that has led me to leave you for dead


So don't trust me

I'm risky
  

Insurmountable unaccountable
	*rhyme*
I'm an undeniable unreliable maniacal liability
	*internal rhyme*
I fire soliloquies and my liturgies literally leave a literary litany
	*cacophony*


You see

When I was little

They told me I was:

Illegitimate, illiterate and limited

Little did they know that in a minute I'd be killing it

I'm vivid like in cinemas

So my synonym is vividness

I stick it like I'm cinnamon

And kill it like a militant

I live it like a citizen - you live a life like imprisonment

Besides Indigenous, immigrant might be the most legitimate of citizens

  
So it’s better to live a life like us… 

Isn't it?

## Analysis 
The immigrant community aren't victims: they are only getting stronger and united as they get discriminated. 