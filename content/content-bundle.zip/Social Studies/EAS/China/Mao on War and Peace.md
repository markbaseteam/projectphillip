---
tags:
- EAS
- extract
- china
- history
---
# Mao on War and Peace 
Created: 2022-05-30 06:32  

>We are advocates of the abolition of war, we do not want war; but war can only be abolished through war, and in order to get rid of the gun it is necessary to take up the gun. (Problems of War and Strategy" (November 6, 1938), Selected Works, Vol. II, p. 225.) ^maoonwarandpeace

>Revolutionary war is an antitoxin that not only eliminates the enemy's poison but also purges us of our own filth. Every just, revolutionary war is endowed with tremendous power and can transform many things or clear the way for their transformation. The Sino-Japanese war will transform both China and Japan; provided China perseveres in the War of Resistance and in the united front, the old Japan will surely be transformed into a new Japan and the old China into a new China, and people and everything else in both China and Japan will be transformed during and after the war. ("On Protracted War" (May 1938), Selected Works, Vol. II, p. 131.) 

---
## References 
- http://large.stanford.edu/history/kaist/references/marx/mao/c5/