# Tarin's Math Problem
Created: 2022-04-06 19:45
Tags: #Math 

Solve for x:
$$\frac{5}{x(x+2)}+7=\frac{x+1}{x}$$

After 35 minutes of doing the same thing over and over again because stupid mistakes, I find the solution: 

![[Screen Shot 2022-04-06 at 7.27.04 PM.png]]

Found immense joy in finally finishing that problem. Frankly, it made my day. It's the small things in life. (Also somehow noticing that without this text within the parentheses the word count is 69)