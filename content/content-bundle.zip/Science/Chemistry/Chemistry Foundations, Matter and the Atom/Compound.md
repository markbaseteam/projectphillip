---
tags:
- Science
- Chemistry
- Definition
Created: 2022-08-18 21:21  
---
# Compound 

A substance that results from a combination of two or more different [[chemical]] [[Element|elements]], in such a way that the [[atom|atoms]] of the different elements are held together by chemical bonds that are difficult to break. Each compound is made from the atoms of two or more elements that are chemically bonded. 

![[Pasted image 20220818212225.png]]