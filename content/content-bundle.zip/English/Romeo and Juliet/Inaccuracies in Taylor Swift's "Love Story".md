---
tags:
- English
- Shakespeare
- music
- extract
---
# Inaccuracies in Taylor Swift's “Love Story” 
Created: 2022-05-27 09:35  

Apparently, Taylor Swift got some details mixed up and put some inaccurate content in her song, [Love Story](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjD9sr9tv73AhVSmVYBHe_9ASEQwqsBegQIIRAB&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DhQeokpMNXW8&usg=AOvVaw21dvnGLlK72MKoC7Ihj9Ad). 

We were both young when I first saw you  
I close my eyes and the flashback starts  
I'm standin' there  
On a balcony in summer air  
See the lights, see the party, the ball gowns  
See you make your way through the crowd  
And say, "Hello"  
Little did I know

That you were Romeo, you were throwin' pebbles  
And my daddy said, "Stay away from Juliet"  
And I was cryin' on the staircase  
Beggin' you, "Please don't go, " and I said

Romeo, take me somewhere we can be alone  
I'll be waiting, all there's left to do is run  
You'll be the prince and I'll be the princess  
It's a love story, baby, just say, "Yes"

So I sneak out to the garden to see you  
We keep quiet, 'cause we're dead if they knew  
So close your eyes  
Escape this town for a little while, oh oh

'Cause you were Romeo, I was a scarlet letter  
And my daddy said, "Stay away from Juliet"  
But you were everything to me  
I was beggin' you, "Please don't go, " and I said

Romeo, take me somewhere we can be alone  
I'll be waiting, all there's left to do is run  
You'll be the prince and I'll be the princess  
It's a love story, baby, just say, "Yes"  
Romeo, save me, they're tryna tell me how to feel  
This love is difficult, but it's real  
Don't be afraid, we'll make it out of this mess  
It's a love story, baby, just say, "Yes"  
Oh, oh

I got tired of waiting  
Wonderin' if you were ever comin' around  
My faith in you was fading  
When I met you on the outskirts of town, and I said

Romeo, save me, I've been feeling so alone  
I keep waiting for you, but you never come  
Is this in my head? I don't know what to think  
He knelt to the ground and pulled out a ring  
And said, "Marry me, Juliet  

>Romeo never proposed to Juliet or gave a ring to her. It was actually the opposite: Juliet mentioned marriage to Romeo and she was the one who gave Romeo a ring with the Nurse’s help. 

You'll never have to be alone  
I love you and that's all I really know  
I talked to your dad, go pick out a white dress  

>Romeo never talked to Lord Capulet. 

It's a love story, baby, just say, "Yes"  
Oh, oh, oh  
Oh, oh, oh, oh  
'Cause we were both young when I first saw you