---
tags:
- SouthAfrica 
- History 
Created: 2022-08-23 14:07  
---
# Swahili City-states 
“People of the coast” in Arabic. Powerful cities.

![[Pasted image 20220823141043.png]]

>[!important] Why Arabic? 
Since they’re so close to each other, Arabic culture diffused into the city-states through **Indian ocean trade**.

## Culture 
African culture + Arabic culture = Swahili culture 
Conversion to Islam by the 8th century 