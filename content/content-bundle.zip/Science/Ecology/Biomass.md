# Biomass 
Created: 2022-04-28 05:30  
Tags: #Definition #Science #Ecology 

## :measure of the total dry mass of organisms in a given area 
- Basically the mass of alive things 
	- ex. I have more biomass than a 5yr old, while an elephant has more biomass than me 

**During the conversion of one biomass to another (ex. grass to cow), much of the energy from the lower [[trophic level]] is lost to the consumer, as majority of the energy was used to keep the food alive.** 

- Also a source for energy that humans can convert to electricity & heat 